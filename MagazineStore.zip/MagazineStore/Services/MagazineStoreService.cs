﻿using MagazineStore.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace MagazineStore.Services
{
    public class MagazineStoreService
    {
        private readonly string tokenUrl = "http://magazinestore.azurewebsites.net/api/token";
        private readonly string categoriesUrl = "http://magazinestore.azurewebsites.net/api/categories/";
        private readonly string magazineUrl = "http://magazinestore.azurewebsites.net/api/magazines/";
        private readonly string subscriberUrl = "http://magazinestore.azurewebsites.net/api/subscribers/";
        private readonly string submitAnswerUrl = "http://magazinestore.azurewebsites.net/api/answer/";

        public void SubmitAnswer()
        {
            var token = GetToken();

            if (!string.IsNullOrEmpty(token))
            {
                var categories = GetCategories(token);

                if (categories != null && categories.Count > 0)
                {
                    List<Magazine> allMagazines = new List<Magazine>();

                    foreach (var category in categories)
                    {
                        var magazines = GetMagazines(category, token);

                        allMagazines.AddRange(magazines);
                    }

                    var subscribers = GetMagazineSubscribers(token);

                    var subscribersToSubmit = GetSubscribersToSubmit(subscribers, allMagazines, categories);

                    SubmitAnswer(subscribersToSubmit, token);
                }
                else
                {
                    Console.WriteLine("Category not available.");
                }
            }
            else
            {
                Console.WriteLine("Token not found.");
            }
        }

        private string GetToken()
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync(tokenUrl).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var baseResponse = JsonConvert.DeserializeObject<BaseResponse>(result);

                    return baseResponse.Token;
                }
                else
                {
                    return "";
                }
            }
        }

        private IList<string> GetCategories(string token)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync(categoriesUrl + token).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var category = JsonConvert.DeserializeObject<Category>(result);

                    return category.Data;
                }
                else
                {
                    return new List<string>();
                }
            }
        }

        private IList<Magazine> GetMagazines(string category, string token)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync(magazineUrl + token + "/" + category).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var magazine = JsonConvert.DeserializeObject<MagazineDetail>(result);

                    return magazine.Data;
                }
                else
                {
                    return new List<Magazine>();
                }
            }
        }

        private IList<Subscriber> GetMagazineSubscribers(string token)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync(subscriberUrl + token).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var magazineSubscribed = JsonConvert.DeserializeObject<SubscriberDetail>(result);

                    return magazineSubscribed.Data;
                }
                else
                {
                    return new List<Subscriber>();
                }
            }
        }

        private void SubmitAnswer(List<string> subscriberIds, string token)
        {
            SubcriberPickItem subcriberPickItem = new SubcriberPickItem()
            {
                Subscribers = new List<string>() { }

            };

            subcriberPickItem.Subscribers.AddRange(subscriberIds);

            using (var client = new HttpClient())
            {
                var response = client.PostAsJsonAsync(submitAnswerUrl + token, subcriberPickItem).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;

                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine("Error occurred during answer submit.");
                }
            }
        }

        private List<string> GetSubscribersToSubmit(IList<Subscriber> subscribers, List<Magazine> magazinesList, IList<string> categories)
        {
            List<string> subscribersToSubmit = new List<string>();

            foreach (var subscriber in subscribers)
            {
                var SubscribedMagazineCategories = new List<string>();

                foreach (var magazineId in subscriber.MagazineIds)
                {
                    var category = magazinesList.Where(m => m.Id == magazineId).Select(m => m.Category).FirstOrDefault();
                    SubscribedMagazineCategories.Add(category);
                }

                var isAtleastOneMagazineSubscribed = categories.All(c => SubscribedMagazineCategories.Any(smc => smc == c));

                if (isAtleastOneMagazineSubscribed)
                {
                    subscribersToSubmit.Add(subscriber.Id);
                }
            }

            return subscribersToSubmit;
        }
    }
}
