﻿## MagazineStore

Magazine Store identifies all subscribers who are subscribed to at least one magazine in each category and submit their id's.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

## Prerequisites

* Visual Studio 2019

## Installing

* Install Visual Studio 2019

## Running the Application

* Unzip the MagazineStore project

* Double click the solution file (MagazineStore.sln)

* Visual studio will be opened and MagazineStore project will be visible

* Press F5 button

* Once the excution is completed successfully, the result will be printed in the console.

## Author

**Hari Kishan**