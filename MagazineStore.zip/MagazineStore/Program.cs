﻿using MagazineStore.Services;

namespace MagazineStore
{
    class Program
    {
        static void Main(string[] args)
        {
            MagazineStoreService service = new MagazineStoreService();
            service.SubmitAnswer();
        }
    }
}
