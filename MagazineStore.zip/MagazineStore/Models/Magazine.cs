﻿using System.Collections.Generic;

namespace MagazineStore.Models
{
    public class MagazineDetail : BaseResponse
    {
        public IList<Magazine> Data { get; set; }
    }

    public class Magazine
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Category { get; set; }
    }
}
