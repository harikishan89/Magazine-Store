﻿using System.Collections.Generic;

namespace MagazineStore.Models
{
    public class SubscriberDetail : BaseResponse
    {
        public IList<Subscriber> Data { get; set; }
    }

    public class Subscriber
    {
        public string Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public List<int> MagazineIds { get; set; }
    }

    public class SubcriberPickItem
    {
        public List<string> Subscribers { get; set; }
    }
}
