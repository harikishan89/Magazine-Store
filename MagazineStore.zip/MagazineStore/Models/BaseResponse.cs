﻿namespace MagazineStore.Models
{
    public class BaseResponse
    {
        public bool Success { get; set; }

        public string Token { get; set; }
    }
}
