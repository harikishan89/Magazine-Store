﻿using System.Collections.Generic;

namespace MagazineStore.Models
{
    public class Category : BaseResponse
    {
        public IList<string> Data { get; set; }
    }
}
